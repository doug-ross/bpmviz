from pathlib import Path
from playwright.sync_api import sync_playwright
import re,json
ROOT=Path('/mnt/data/bpmviz_audit/bpmviz-main');OUT=ROOT.parent/'evidence'
def html_for(rel,inject=''):
    path=ROOT/rel
    def script(m):
        code=(path.parent/m.group(1)).read_text()
        if m.group(1)=='process.js':code+='\n'+inject
        return '<script>'+code+'</script>'
    s=re.sub(r'<script src="([^\"]+)"></script>',script,path.read_text())
    return re.sub(r'<link rel="stylesheet" href="([^\"]+)">',lambda m:'<style>'+(path.parent/m.group(1)).read_text()+'</style>',s)
r={}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 def page_for(rel,inject=''):
    c=b.new_context(viewport={'width':1440,'height':900},reduced_motion='reduce')
    c.route('**/*',lambda route:route.abort())
    page=c.new_page();page.set_content(html_for(rel,inject),wait_until='load');page.wait_for_timeout(120)
    return page,c
 v='racer/webui-v2-astra/index.htm'
 page,c=page_for(v)
 r['metric_rows']=page.locator('#mtBody').inner_text()
 r['reduced_motion_start']=page.locator('#play').inner_text()
 page.locator('#caseSel').select_option('0');r['paused_after_case_change']=page.locator('#play').inner_text()
 page.locator('#toEnd').click();r['paused_after_end']=page.locator('#play').inner_text()
 page.locator('#restart').click();r['paused_after_rewind']=page.locator('#play').inner_text()
 page.locator('#zfit').click();page.screenshot(path=str(OUT/'astra_v2_fit_all_1440x900.png'))
 r['fit_all_zoom']=page.locator('#zpct').inner_text()
 r['fit_all_font_sample']=page.evaluate('''() => [...document.querySelectorAll('g.node text')].filter(e=>e.textContent.includes('Clearance')).slice(0,4).map(e=>({text:e.textContent,sourceFont:getComputedStyle(e).fontSize,renderedFont:parseFloat(getComputedStyle(e).fontSize)*Math.hypot(e.getScreenCTM().a,e.getScreenCTM().b)}))''')
 c.close()
 for test,inject in [('before_only','window.PROCESS.after=null;'),('invalid_lane','window.PROCESS.before.nodes[0].lane="missing-lane";'),('negative_time','window.PROCESS.before.nodes[0].s=-1;'),('after_slower','window.PROCESS.cases.forEach(c=>c.a=c.b*2);')]:
    page,c=page_for(v,inject)
    r[test]={'error':page.locator('.error').inner_text() if page.locator('.error').count() else None,'body':page.inner_text('body')[:1800]}
    if test=='before_only':r[test]['afterHidden']=page.locator('#trkAfter').evaluate('(e)=>e.hidden')
    if test=='after_slower':page.locator('#toEnd').click();r[test]['clockAtEnd']=page.locator('#clock').inner_text()
    c.close()
 page,c=page_for('webui/index.htm')
 page.evaluate('''() => {setPlaying(false);SUBMISSIONS[0].summary='<strong id="audit-untrusted-marker">Untrusted markup marker</strong>';STATE.selectedNode=null;renderDetail();}''')
 r['main_untrusted_html_parsed']=page.locator('#audit-untrusted-marker').count()==1
 c.close()
 page,c=page_for(v,'window.PROCESS.before.nodes[0].detail.desc=\'<strong id="audit-untrusted-marker">Untrusted markup marker</strong>\';')
 page.locator('g.node[tabindex="0"]').first.focus();page.keyboard.press('Enter')
 r['v2_untrusted_html_parsed']=page.locator('#audit-untrusted-marker').count()>0
 r['v2_untrusted_html_literal_visible']='<strong' in page.locator('#detailWrap').inner_text()
 c.close();b.close()
(OUT/'focused_tests.json').write_text(json.dumps(r,indent=2,ensure_ascii=False))
print(json.dumps(r,indent=2,ensure_ascii=True))
