from pathlib import Path
from playwright.sync_api import sync_playwright
import json, traceback, re
import http.server, threading, functools
ROOT=Path('/mnt/data/bpmviz_audit/bpmviz-main')
OUT=Path('/mnt/data/bpmviz_audit/evidence')
APPS={'explorer':'webui/index.htm','racer':'racer/webui/index.htm','astra_v2':'racer/webui-v2-astra/index.htm'}
SIZES=[(1366,768),(1440,900),(1920,1080),(2560,1440),(1024,768)]
server=http.server.ThreadingHTTPServer(("127.0.0.1",0),functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
BASE=f"http://127.0.0.1:{server.server_port}/"
results={}
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    for name,rel in APPS.items():
        errors=[]; blocked=[]
        context=browser.new_context(viewport={'width':1440,'height':900},reduced_motion='reduce')
        def route_fn(route):
            if route.request.url.startswith(('file:','data:','blob:',BASE)):route.continue_()
            else:blocked.append(route.request.url);route.abort()
        context.route('**/*',route_fn)
        page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
        try:
            html=(ROOT/rel).read_text()
            parent=(ROOT/rel).parent
            html=re.sub(r'<script src="([^"]+)"></script>',lambda m:'<script>'+ (parent/m.group(1)).read_text()+'</script>',html)
            html=re.sub(r'<link rel="stylesheet" href="([^"]+)">',lambda m:'<style>'+ (parent/m.group(1)).read_text()+'</style>',html)
            page.set_content(html,wait_until='load',timeout=15000)
            page.wait_for_timeout(500)
            data={'title':page.title(),'initial_body':page.inner_text('body')[:18000]}
            play='#btn-play' if name=='explorer' else '#play'
            if name=='explorer':
                page.evaluate('setPlaying(false); STATE.simT=0; updateNodeVisuals();')
            else:
                text=page.locator(play).inner_text()
                if 'Stop' in text or '\u23f8' in text: page.locator(play).click()
            data['viewports']=[]
            for w,h in SIZES:
                page.set_viewport_size({'width':w,'height':h});page.wait_for_timeout(180)
                fn=f'{name}_{w}x{h}.png';page.screenshot(path=str(OUT/fn),full_page=False)
                dim=page.evaluate('''() => ({body:{w:document.body.scrollWidth,h:document.body.scrollHeight},viewport:{w:innerWidth,h:innerHeight},panels:[...document.querySelectorAll('.canvas-wrap,.sidebar,.track,.toolbar,.viewport,.gutter')].map(e=>({selector:e.className,rect:{x:e.getBoundingClientRect().x,y:e.getBoundingClientRect().y,w:e.getBoundingClientRect().width,h:e.getBoundingClientRect().height},scrollH:e.scrollHeight,scrollW:e.scrollWidth})),focusableNodes:document.querySelectorAll('svg [tabindex="0"]').length})''')
                data['viewports'].append({'size':[w,h],'screenshot':fn,'layout':dim})
            page.set_viewport_size({'width':1440,'height':900});page.wait_for_timeout(200)
            if name=='explorer':
                data['rework_test']=page.evaluate('''() => {const sub=SUBMISSIONS.find(s=>s.id==='pay004') || SUBMISSIONS.find(s=>s.status==='stuck');const visits=sub.path.filter(p=>p.nodeId==='developBot');const active=sub.path.filter(p=>9100>=p.t&&9100<p.t+p.dur);return {submission:sub.id,visits,at9100:nodeStateAt('developBot',9100,sub),actualActiveVisits:active};}''')
                data['geometry_collision']=page.evaluate('''() => {let out=[];for(let i=0;i<NODES.length;i++) for(let j=i+1;j<NODES.length;j++){let a=nodeXY(NODES[i]),b=nodeXY(NODES[j]);if(a.x===b.x&&a.y===b.y)out.push([NODES[i].id,NODES[j].id,a]);}return out;}''')
                data['wrong_branch_test']=page.evaluate('''() => {const sub=SUBMISSIONS[0];return {sample:sub.name,hasReworkVisit:sub.path.filter(p=>p.nodeId==='developBot').length,defectsEdgeAt4000:flowVisited(FLOWS.find(f=>f.label==='Defects'),4000,sub),qaGatewayState:nodeStateAt('qaGate',4000,sub)};}''')
                page.evaluate("selectSubmission(SUBMISSIONS.findIndex(s=>s.status==='stuck')); STATE.simT=9100;setPlaying(false);STATE.selectedNode='developBot';updateNodeVisuals();renderDetail();")
                page.wait_for_timeout(150);data['rework_detail']=page.locator('#detail-panel').inner_text();page.screenshot(path=str(OUT/'explorer_rework_defect.png'))
                page.locator('#btn-help').click();data['help_accessibility']=page.evaluate("({active:document.activeElement.id,modalRole:document.querySelector('#help-modal').getAttribute('role'),ariaModal:document.querySelector('#help-modal').getAttribute('aria-modal')})")
            elif name=='astra_v2':
                data['configuration'] = page.evaluate('''() => ({beforeNodes:PROCESS.before.nodes.length,afterNodes:PROCESS.after.nodes.length,beforeLanes:PROCESS.before.lanes.length,afterLanes:PROCESS.after.lanes.length,caseCount:PROCESS.cases.length,ids:PROCESS.before.nodes.map(n=>n.id??null),scenarios:PROCESS.cases})''')
                page.locator('#toEnd').click();page.wait_for_timeout(200)
                data['offroute_state']=page.evaluate('''() => [...document.querySelectorAll('#svgBefore .node')].map(g=>({label:g.nodeData?.label,opt:g.nodeData?.opt,s:g.nodeData?.s,e:g.nodeData?.e,state:g.state,class:g.getAttribute('class')})).filter(n=>n.opt)''')
                if not data['offroute_state']:
                    data['offroute_state']=page.evaluate('''() => [...document.querySelectorAll('g')].filter(g=>g.nodeData?.opt).map(g=>({label:g.nodeData.label,s:g.nodeData.s,e:g.nodeData.e,state:g.state,class:g.getAttribute('class')}))''')
                page.screenshot(path=str(OUT/'astra_v2_end_offroute.png'))
                page.locator('#help').click();page.wait_for_timeout(100)
                data['help_accessibility']=page.evaluate("({active:document.activeElement.id,dialogOpen:document.querySelector('#detailWrap').open,dialogTag:document.querySelector('#detailWrap').tagName})")
                data['help_text']=page.locator('#detailWrap').inner_text();page.keyboard.press('Escape')
                node=page.locator('g.node[tabindex="0"]').first
                if node.count():
                    node.focus();page.keyboard.press('Enter');page.wait_for_timeout(100);data['node_keyboard_dialog']=page.locator('#detailWrap').evaluate('(e)=>e.open');data['node_detail']=page.locator('#detailWrap').inner_text();page.keyboard.press('Escape')
                data['inputs']=page.evaluate('([...document.querySelectorAll("input,textarea,[contenteditable]")].map(e=>({tag:e.tagName,type:e.type})))')
            data['errors']=errors;data['external_requests_blocked']=sorted(set(blocked));results[name]=data
        except Exception as e: results[name]={'exception':str(e),'traceback':traceback.format_exc(),'errors':errors,'blocked':blocked}
        context.close()
    browser.close()
server.shutdown()
(OUT/'browser_results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
for name,d in results.items():
    print(name, json.dumps({k:v for k,v in d.items() if k in ['exception','errors','external_requests_blocked','rework_test','geometry_collision','wrong_branch_test','rework_detail','offroute_state','help_accessibility','node_keyboard_dialog','storage']},indent=2))
